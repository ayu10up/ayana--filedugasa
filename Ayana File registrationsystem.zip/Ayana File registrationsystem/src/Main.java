// NAME : AYANA FILE DUGASA
// ID   : 2226/14
//SECTION : A
import java.sql.Connection;
import java.sql.DriverManager;
public class Main {
    public static void main(String[] args) {
        try{
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","ayu10upmemysql");
            System.out.println(con);}
        catch (Exception e){

        }

    }
}