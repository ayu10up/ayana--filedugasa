// NAME : AYANA FILE DUGASA
// ID   : 2226/14
//SECTION : A
class Person {
    protected String firstName;
    protected String middleName;
    protected String lastName;
    protected int age;

    public Person(String firstName, String middleName, String lastName, int age) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }
}